## API interface definitions



#* Echo back the input
#* @param msg The message to echo.
#' @get /echo
function(msg="") {
  list(msg = paste0("The message is: '", msg, "'"))
}


#* Adds a package to the package registry
#* @param file:file File to send
#* @param overwrite Logical, whether to overwrite previous existing package with same filename/version. If true and previous version does not exists, it will fail.
#* @post /add
# curl -X POST "http://127.0.0.1:9961/add" -H "accept: */*" -H "Content-Type: multipart/form-data" -F "file=@DESCRIPTION"
function(file, overwrite=FALSE) {
  fn <- tempfile()
  writeBin(file[[1]], fn)



  str(file)
  multipart <- mime::parse_multipart(file)
  str(multipart)
  ## shuld return status 200
  stop("Not implemented")
}

